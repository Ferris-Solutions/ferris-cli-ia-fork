Ferris Cli
=====================
[![Downloads](https://pepy.tech/badge/ferris-cli)](https://pepy.tech/project/ferris-cli)

The following library simplifies the process of 
* forwarding Metrics and Task to a Kafka consumer.
* storing and retreiving application properties on the Ferris Platform
* setting up scheduler actions from within the Ferris Platform

SEE WIKI FOR MORE DETAILS
